
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `subject_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `causer_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `properties` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_log_log_name_index` (`log_name`),
  KEY `subject` (`subject_id`,`subject_type`),
  KEY `causer` (`causer_id`,`causer_type`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'role','created',1,'App\\Models\\Entities\\Role',NULL,NULL,'{\"attributes\":{\"title\":\"Admin\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(2,'role','created',2,'App\\Models\\Entities\\Role',NULL,NULL,'{\"attributes\":{\"title\":\"Author\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(3,'role','created',3,'App\\Models\\Entities\\Role',NULL,NULL,'{\"attributes\":{\"title\":\"User\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(4,'permission','created',1,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Add role\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(5,'permission','created',2,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Update role\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(6,'permission','created',3,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Delete role\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(7,'permission','created',4,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Add user\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(8,'permission','created',5,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Update user\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(9,'permission','created',6,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Delete user\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(10,'permission','created',7,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Add permission\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(11,'permission','created',8,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Update permission\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(12,'permission','created',9,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Delete permission\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(13,'permission','created',10,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Add inactive slide\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(14,'permission','created',11,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Update inactive slide\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(15,'permission','created',12,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Delete inactive slide\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(16,'permission','created',13,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Update active slide\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(17,'permission','created',14,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Delete active slide\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(18,'permission','created',15,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Add updates\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(19,'permission','created',16,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Update updates\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(20,'permission','created',17,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"Delete updates\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(21,'permission','created',18,'App\\Models\\Entities\\Permission',NULL,NULL,'{\"attributes\":{\"title\":\"View log\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(22,'user account','created',1,'App\\Models\\Entities\\User',NULL,NULL,'{\"attributes\":{\"username\":\"admin\",\"password\":\"$2y$10$dZj9yqcQ0UKl2HRWJQOYnuArV.\\/Xf3OA03ETz5qRM2.VNCHcJydv6\",\"email\":\"admin@gmail.com\",\"is_active\":\"Active\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(23,'user account','created',2,'App\\Models\\Entities\\User',NULL,NULL,'{\"attributes\":{\"username\":\"admin\",\"password\":\"$2y$10$OECKBMmj\\/H8URNYmNjjKWOG2puwd0ahiFXIKmpoeT8I1x1LKN8I5i\",\"email\":\"admin@gmail.com\",\"is_active\":\"Active\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(24,'user account','created',3,'App\\Models\\Entities\\User',NULL,NULL,'{\"attributes\":{\"username\":\"admin\",\"password\":\"$2y$10$Px.6W\\/.uhlnZeSXpIPWQa.NCEhk4qXE\\/TEyftvLYkW7XLUD3wqwN6\",\"email\":\"admin@gmail.com\",\"is_active\":\"Active\"}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(25,'user information','created',1,'App\\Models\\Entities\\Personal_info',NULL,NULL,'{\"attributes\":{\"firstname\":\"Elinore Wisozk DVM\",\"lastname\":\"Mrs. Nora Botsford\",\"gender\":\"Male\",\"user_id\":1}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(26,'user department information','created',1,'App\\Models\\Entities\\Department',NULL,NULL,'{\"attributes\":{\"department_name\":\"Juwan Cronin\",\"user_id\":1}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(27,'user information','created',2,'App\\Models\\Entities\\Personal_info',NULL,NULL,'{\"attributes\":{\"firstname\":\"Tremaine Rolfson\",\"lastname\":\"Sonny Koelpin I\",\"gender\":\"Male\",\"user_id\":2}}','2020-06-14 10:31:50','2020-06-14 10:31:50'),(28,'user department information','created',2,'App\\Models\\Entities\\Department',NULL,NULL,'{\"attributes\":{\"department_name\":\"Ms. Nova Lockman\",\"user_id\":2}}','2020-06-14 10:31:51','2020-06-14 10:31:51'),(29,'user information','created',3,'App\\Models\\Entities\\Personal_info',NULL,NULL,'{\"attributes\":{\"firstname\":\"Prof. Jed Heller IV\",\"lastname\":\"Brisa Shields\",\"gender\":\"Male\",\"user_id\":3}}','2020-06-14 10:31:51','2020-06-14 10:31:51'),(30,'user department information','created',3,'App\\Models\\Entities\\Department',NULL,NULL,'{\"attributes\":{\"department_name\":\"Prof. Maynard Morar\",\"user_id\":3}}','2020-06-14 10:31:51','2020-06-14 10:31:51'),(31,'user account','created',4,'App\\Models\\Entities\\User',NULL,NULL,'{\"attributes\":{\"username\":\"sample\",\"password\":\"$2y$10$yOhq02BQ9CY1PIzZwoVCee7MdFmzBmehBKBarm5zS3ti2e6grdygm\",\"email\":\"sample@g.c\",\"is_active\":\"Active\"}}','2020-06-14 10:31:51','2020-06-14 10:31:51'),(32,'user department information','created',4,'App\\Models\\Entities\\Department',NULL,NULL,'{\"attributes\":{\"department_name\":\"Soecs\",\"user_id\":4}}','2020-06-14 10:31:51','2020-06-14 10:31:51'),(33,'login','logged in',NULL,NULL,1,'App\\Models\\Entities\\User','[]','2020-06-14 10:32:06','2020-06-14 10:32:06'),(34,'web update','created',1,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"NIGHT HIGH CLASS BATCH \\\\\'78 REUNION\",\"overview\":null,\"category\":\"news-and-events\"}}','2020-06-14 10:33:07','2020-06-14 10:33:07'),(35,'web update','created',2,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"NIGHT HIGH CLASS BATCH \\\\\'78 REUNION\",\"overview\":null,\"category\":\"news-and-events\"}}','2020-06-14 10:33:07','2020-06-14 10:33:07'),(36,'web update','created',3,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"THE NEW NORTH CAMPUS MAIN GATE\",\"overview\":null,\"category\":\"news-and-events\"}}','2020-06-14 10:34:46','2020-06-14 10:34:46'),(37,'web update','created',4,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"59th FOUNDATION ANNIVERSARY\",\"overview\":null,\"category\":\"news-and-events\"}}','2020-06-14 10:36:49','2020-06-14 10:36:49'),(38,'web update','created',5,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"AN APPEAL FOR UNDERSTANDING\",\"overview\":\"On January 29, 2020 at 4:00 in the afternoon...\",\"category\":\"announcement\"}}','2020-06-14 10:40:27','2020-06-14 10:40:27'),(39,'web update','created',6,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"SUSPENSION OF CLASSES AND WORK: MARCH 13, 2020\",\"overview\":\"[OFFICIAL ANNOUNCEMENT] Memorandum from the Office of the President regarding the suspension of classes in Divine Word College of Legazpi.\",\"category\":\"announcement\"}}','2020-06-14 10:42:50','2020-06-14 10:42:50'),(40,'web update','created',7,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"DIOCESAN CIRCULAR No. 6, Series of 2020\",\"overview\":\"[INFORMATION] Circular from the Roman Catholic Diocese of Legazpi pertaining to precautionary and other-related measures to prevent the spread of COVID19. Please be guided accordingly.\",\"category\":\"announcement\"}}','2020-06-14 10:46:31','2020-06-14 10:46:31'),(41,'web update','created',8,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"Reco-Tour 2020\",\"overview\":\"Please be guided accordingly.\",\"category\":\"announcement\"}}','2020-06-14 10:51:57','2020-06-14 10:51:57'),(42,'web update','created',9,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"GUIDELINES FOR THE CONDUCT OF CLASSES\",\"overview\":null,\"category\":\"announcement\"}}','2020-06-14 10:56:02','2020-06-14 10:56:02'),(43,'web update','created',10,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"DIOCESAN CIRCULAR No. 8, Series of 2020\",\"overview\":null,\"category\":\"announcement\"}}','2020-06-14 10:59:01','2020-06-14 10:59:01'),(44,'web update','created',11,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"OFFICIAL RESPONSE OF THE FATHER PRESIDENT\",\"overview\":\"[INFORMATION] Official Response of the Father President pertaining to the continuation of online classes in DWC Legazpi, for reference and guidance.\",\"category\":\"announcement\"}}','2020-06-14 11:01:35','2020-06-14 11:01:35'),(45,'web update','created',12,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"REVISED SCHOOL ACTIVITIES FOR THE 2ND SEMESTER\",\"overview\":\"In light of recent government updates on CoViD-19, and having in mind the safety and well-being of the school ...\",\"category\":\"announcement\"}}','2020-06-14 11:03:14','2020-06-14 11:03:14'),(46,'web update','created',13,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"GUIDELINES IN POSTING OFFICIAL COMMUNICATION\",\"overview\":null,\"category\":\"announcement\"}}','2020-06-14 11:05:20','2020-06-14 11:05:20'),(47,'web update','created',14,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"ACKNOWLEDGE RECEIPT OF OPEN LETTER DATED MAY 4, 2020\",\"overview\":null,\"category\":\"announcement\"}}','2020-06-14 11:18:03','2020-06-14 11:18:03'),(48,'web update','created',15,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"CHANGES\\/UPDATES TO MEMO NO.9, s. 2020\",\"overview\":null,\"category\":\"announcement\"}}','2020-06-14 11:20:58','2020-06-14 11:20:58'),(49,'web update','created',16,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"CANCELLATION OF TUITION FEE INCREASE, SY 2020-2021\",\"overview\":null,\"category\":\"announcement\"}}','2020-06-14 11:23:21','2020-06-14 11:23:21'),(50,'web update','created',17,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"ENROLLMENT - BASIC EDUCATION\",\"overview\":null,\"category\":\"announcement\"}}','2020-06-14 11:25:02','2020-06-14 11:25:02'),(51,'web update','created',18,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"PLACEMENT TEST FOR GRADE 11 STUDENTS AND TRANSFEREES\",\"overview\":\"Placement test will be administered during the first week of classes for Grade 11 students and transferees.\",\"category\":\"announcement\"}}','2020-06-14 11:27:07','2020-06-14 11:27:07'),(52,'web update','created',19,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"REITERATION OF GUIDELINES AND PROTOCOLS FOR STRICT COMPLIANCE DURING GCQ\",\"overview\":null,\"category\":\"announcement\"}}','2020-06-14 11:28:58','2020-06-14 11:28:58'),(53,'web update','created',20,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"LEARNING DELIVERY MODALITIES\",\"overview\":\"In case you\\u2019re wondering what blended learning is...\",\"category\":\"announcement\"}}','2020-06-14 11:33:28','2020-06-14 11:33:28'),(54,'web update','created',21,'App\\Models\\Entities\\Update',1,'App\\Models\\Entities\\User','{\"attributes\":{\"title\":\"ENTRY PROTOCOLS AT DWCL CAMPUS DURING THE RELEASE OF STUDENTS\' CARDS\",\"overview\":\"ATTN: BASIC ED PARENTS AND\\/OR GUARDIANS on June 15, 2020.\",\"category\":\"announcement\"}}','2020-06-14 11:34:49','2020-06-14 11:34:49');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `content_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `content_types` WRITE;
/*!40000 ALTER TABLE `content_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contents` WRITE;
/*!40000 ALTER TABLE `contents` DISABLE KEYS */;
/*!40000 ALTER TABLE `contents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `department_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `departments_user_id_foreign` (`user_id`),
  CONSTRAINT `departments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'Juwan Cronin',1,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(2,'Ms. Nova Lockman',2,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(3,'Prof. Maynard Morar',3,'2020-06-14 10:31:51','2020-06-14 10:31:51'),(4,'soecs',4,'2020-06-14 10:31:51','2020-06-14 10:31:51');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imageable_id` int(11) NOT NULL,
  `imageable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (1,'batch-78-reunion-1.jpg',1,'App\\Models\\Entities\\Update','2020-06-14 10:33:07','2020-06-14 10:33:07'),(2,'batch-78-reunion-2.jpg',1,'App\\Models\\Entities\\Update','2020-06-14 10:33:07','2020-06-14 10:33:07'),(3,'batch-78-reunion-3.jpg',1,'App\\Models\\Entities\\Update','2020-06-14 10:33:07','2020-06-14 10:33:07'),(4,'batch-78-reunion-4.jpg',1,'App\\Models\\Entities\\Update','2020-06-14 10:33:07','2020-06-14 10:33:07'),(5,'batch-78-reunion-1.jpg',2,'App\\Models\\Entities\\Update','2020-06-14 10:33:07','2020-06-14 10:33:07'),(6,'batch-78-reunion-2.jpg',2,'App\\Models\\Entities\\Update','2020-06-14 10:33:07','2020-06-14 10:33:07'),(7,'batch-78-reunion-3.jpg',2,'App\\Models\\Entities\\Update','2020-06-14 10:33:07','2020-06-14 10:33:07'),(8,'batch-78-reunion-4.jpg',2,'App\\Models\\Entities\\Update','2020-06-14 10:33:07','2020-06-14 10:33:07'),(9,'gate.jpg',3,'App\\Models\\Entities\\Update','2020-06-14 10:34:46','2020-06-14 10:34:46'),(10,'foundation_2020.jpg',4,'App\\Models\\Entities\\Update','2020-06-14 10:36:49','2020-06-14 10:36:49'),(11,'appeal.png',5,'App\\Models\\Entities\\Update','2020-06-14 10:40:27','2020-06-14 10:40:27'),(12,'mar-13-2020%20suspension-class-work.jpg',6,'App\\Models\\Entities\\Update','2020-06-14 10:42:50','2020-06-14 10:42:50'),(13,'diocesan-circular-no_6-1.jpg',7,'App\\Models\\Entities\\Update','2020-06-14 10:46:31','2020-06-14 10:46:31'),(14,'diocesan-circular-no_6-2.jpg',7,'App\\Models\\Entities\\Update','2020-06-14 10:46:31','2020-06-14 10:46:31'),(15,'reco-tour-2020.jpg',8,'App\\Models\\Entities\\Update','2020-06-14 10:51:57','2020-06-14 10:51:57'),(16,'mar-17-2020%20guideline-classes.jpg',9,'App\\Models\\Entities\\Update','2020-06-14 10:56:02','2020-06-14 10:56:02'),(17,'diocesan-circular-no_8.jpg',10,'App\\Models\\Entities\\Update','2020-06-14 10:59:01','2020-06-14 10:59:01'),(18,'apr-01-2020%20father-response.jpg',11,'App\\Models\\Entities\\Update','2020-06-14 11:01:35','2020-06-14 11:01:35'),(19,'apr-14-2020%20revised-school-activities.jpg',12,'App\\Models\\Entities\\Update','2020-06-14 11:03:15','2020-06-14 11:03:15'),(20,'apr-21-2020%20guidelines-posting-communication.jpg',13,'App\\Models\\Entities\\Update','2020-06-14 11:05:20','2020-06-14 11:05:20'),(21,'may-14-2020%20acknowledge-receipt-letter.jpg',14,'App\\Models\\Entities\\Update','2020-06-14 11:18:03','2020-06-14 11:18:03'),(22,'may-14-2020%20acknowledge-receipt-letter-2.jpg',14,'App\\Models\\Entities\\Update','2020-06-14 11:18:03','2020-06-14 11:18:03'),(23,'may-14-2020%20changes-updates-memo.jpg',15,'App\\Models\\Entities\\Update','2020-06-14 11:20:58','2020-06-14 11:20:58'),(24,'may-14-2020%20changes-updates-memo-2.jpg',15,'App\\Models\\Entities\\Update','2020-06-14 11:20:58','2020-06-14 11:20:58'),(25,'may-14-2020%20changes-updates-memo-3.jpg',15,'App\\Models\\Entities\\Update','2020-06-14 11:20:58','2020-06-14 11:20:58'),(26,'may-21-2020%20tuition-fee-cancellation.jpg',16,'App\\Models\\Entities\\Update','2020-06-14 11:23:21','2020-06-14 11:23:21'),(27,'may-27-2020%20enrollment-basic-ed.jpg',17,'App\\Models\\Entities\\Update','2020-06-14 11:25:02','2020-06-14 11:25:02'),(28,'may-21-2020%20placement-test-grade-11-and-transferees-01.jpg',18,'App\\Models\\Entities\\Update','2020-06-14 11:27:07','2020-06-14 11:27:07'),(29,'may-21-2020%20placement-test-grade-11-and-transferees-02.jpg',18,'App\\Models\\Entities\\Update','2020-06-14 11:27:07','2020-06-14 11:27:07'),(30,'may-23-2020%20reiteration-guidelines-protocols.jpg',19,'App\\Models\\Entities\\Update','2020-06-14 11:28:58','2020-06-14 11:28:58'),(31,'jun-06-2020%20learning-delivery-modalities.jpg',20,'App\\Models\\Entities\\Update','2020-06-14 11:33:28','2020-06-14 11:33:28'),(32,'jun-10-2020%20entry-protocol-release-of-cards.jpg',21,'App\\Models\\Entities\\Update','2020-06-14 11:34:49','2020-06-14 11:34:49');
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2020_01_21_074251_create_content_types_table',1),(5,'2020_01_21_074308_create_departments_table',1),(6,'2020_01_21_074332_create_images_table',1),(7,'2020_01_21_074550_create_contents_table',1),(8,'2020_01_24_014143_change_email_default_value_in_users_table',1),(9,'2020_04_09_211814_create_activity_log_table',1),(10,'2020_04_18_153626_create_jobs_table',1),(11,'2020_04_20_164132_create_personal_infos_table',1),(12,'2020_05_07_215536_create_roles_table',1),(13,'2020_05_07_220241_create_permissions_table',1),(14,'2020_05_07_221838_create_role_user_table',1),(15,'2020_05_07_221938_create_role_permission_table',1),(16,'2020_06_01_210412_create_slides_table',1),(17,'2020_06_01_210910_create_updates_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_role_role_id_foreign` (`role_id`),
  KEY `permission_role_permission_id_foreign` (`permission_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
INSERT INTO `permission_role` VALUES (1,1,1,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(2,1,2,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(3,1,3,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(4,1,4,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(5,1,5,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(6,1,6,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(7,1,7,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(8,1,8,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(9,1,9,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(10,1,10,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(11,1,11,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(12,1,12,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(13,1,13,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(14,1,14,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(15,1,15,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(16,1,16,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(17,1,17,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(18,1,18,'2020-06-14 10:31:50','2020-06-14 10:31:50');
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'add role','2020-06-14 10:31:50','2020-06-14 10:31:50'),(2,'update role','2020-06-14 10:31:50','2020-06-14 10:31:50'),(3,'delete role','2020-06-14 10:31:50','2020-06-14 10:31:50'),(4,'add user','2020-06-14 10:31:50','2020-06-14 10:31:50'),(5,'update user','2020-06-14 10:31:50','2020-06-14 10:31:50'),(6,'delete user','2020-06-14 10:31:50','2020-06-14 10:31:50'),(7,'add permission','2020-06-14 10:31:50','2020-06-14 10:31:50'),(8,'update permission','2020-06-14 10:31:50','2020-06-14 10:31:50'),(9,'delete permission','2020-06-14 10:31:50','2020-06-14 10:31:50'),(10,'add inactive slide','2020-06-14 10:31:50','2020-06-14 10:31:50'),(11,'update inactive slide','2020-06-14 10:31:50','2020-06-14 10:31:50'),(12,'delete inactive slide','2020-06-14 10:31:50','2020-06-14 10:31:50'),(13,'update active slide','2020-06-14 10:31:50','2020-06-14 10:31:50'),(14,'delete active slide','2020-06-14 10:31:50','2020-06-14 10:31:50'),(15,'add updates','2020-06-14 10:31:50','2020-06-14 10:31:50'),(16,'update updates','2020-06-14 10:31:50','2020-06-14 10:31:50'),(17,'delete updates','2020-06-14 10:31:50','2020-06-14 10:31:50'),(18,'view log','2020-06-14 10:31:50','2020-06-14 10:31:50');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_infos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `personal_infos_user_id_foreign` (`user_id`),
  CONSTRAINT `personal_infos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_infos` WRITE;
/*!40000 ALTER TABLE `personal_infos` DISABLE KEYS */;
INSERT INTO `personal_infos` VALUES (1,'Elinore Wisozk DVM','Mrs. Nora Botsford','male',1,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(2,'Tremaine Rolfson','Sonny Koelpin I','male',2,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(3,'Prof. Jed Heller IV','Brisa Shields','male',3,'2020-06-14 10:31:51','2020-06-14 10:31:51');
/*!40000 ALTER TABLE `personal_infos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_user_user_id_index` (`user_id`),
  KEY `role_user_role_id_index` (`role_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,1,1,'2020-06-14 10:31:50','2020-06-14 10:31:50'),(2,2,2,'2020-06-14 10:31:51','2020-06-14 10:31:51'),(3,3,3,'2020-06-14 10:31:51','2020-06-14 10:31:51'),(4,4,2,'2020-06-14 10:31:51','2020-06-14 10:31:51');
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','2020-06-14 10:31:50','2020-06-14 10:31:50'),(2,'author','2020-06-14 10:31:50','2020-06-14 10:31:50'),(3,'user','2020-06-14 10:31:50','2020-06-14 10:31:50');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `slides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slides` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `number` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `slides` WRITE;
/*!40000 ALTER TABLE `slides` DISABLE KEYS */;
/*!40000 ALTER TABLE `slides` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `updates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `overview` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paragraph` text COLLATE utf8mb4_unicode_ci,
  `clickable` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `updates_user_id_foreign` (`user_id`),
  CONSTRAINT `updates_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `updates` WRITE;
/*!40000 ALTER TABLE `updates` DISABLE KEYS */;
INSERT INTO `updates` VALUES (1,'NIGHT HIGH CLASS BATCH \'78 REUNION','news-and-events',NULL,'<p><strong>WHEN:</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;November 30, 2019</p>\r\n\r\n<p><strong>WHERE:</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;Bogtong Elementary School</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;Covered Court</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;7:00 A.M. - 7:00 P.M.</p>\r\n\r\n<p><img alt=\"\" src=\"/storage/img/updates/images/batch-78-reunion-1.jpg\" /><img alt=\"\" src=\"/storage/img/updates/images/batch-78-reunion-2.jpg\" /><img alt=\"\" src=\"/storage/img/updates/images/batch-78-reunion-3.jpg\" /><img alt=\"\" src=\"/storage/img/updates/images/batch-78-reunion-4.jpg\" /></p>',1,1,'2020-02-11 08:48:30','2020-02-11 08:48:30'),(3,'THE NEW NORTH CAMPUS MAIN GATE','news-and-events',NULL,'<p><img alt=\"\" src=\"/storage/img/updates/images/gate.jpg\" /></p>',1,1,'2020-02-11 08:48:31','2020-02-11 08:48:31'),(4,'59th FOUNDATION ANNIVERSARY','news-and-events',NULL,'<p><img alt=\"\" src=\"/storage/img/updates/images/foundation_2020.jpg\" /></p>',1,1,'2020-02-11 08:48:32','2020-02-11 08:48:32'),(5,'AN APPEAL FOR UNDERSTANDING','announcement','On January 29, 2020 at 4:00 in the afternoon...','<p><img alt=\"\" src=\"/storage/img/updates/images/announcements/appeal.png\" /></p>',1,1,'2020-02-11 08:48:33','2020-02-11 08:48:30'),(6,'SUSPENSION OF CLASSES AND WORK: MARCH 13, 2020','announcement','[OFFICIAL ANNOUNCEMENT] Memorandum from the Office of the President regarding the suspension of classes in Divine Word College of Legazpi.','<p><img alt=\"\" src=\"/storage/img/updates/images/mar-13-2020%20suspension-class-work.jpg\" /></p>',1,1,'2020-03-13 08:48:30','2020-03-13 08:48:30'),(7,'DIOCESAN CIRCULAR No. 6, Series of 2020','announcement','[INFORMATION] Circular from the Roman Catholic Diocese of Legazpi pertaining to precautionary and other-related measures to prevent the spread of COVID19. Please be guided accordingly.','<p>[INFORMATION] Circular from the Roman Catholic Diocese of Legazpi pertaining to precautionary and other-related measures to prevent the spread of COVID19. Please be guided accordingly.</p>\r\n\r\n<p><img alt=\"\" src=\"/storage/img/updates/images/diocesan-circular-no_6-1.jpg\" /></p>\r\n\r\n<p><img alt=\"\" src=\"/storage/img/updates/images/diocesan-circular-no_6-2.jpg\" /></p>',1,1,'2020-03-13 08:48:31','2020-03-13 08:48:31'),(8,'Reco-Tour 2020','announcement','Please be guided accordingly.','<p>Please be guided accordingly.</p>\r\n\r\n<p><img alt=\"\" src=\"/storage/img/updates/images/reco-tour-2020.jpg\" /></p>',1,1,'2020-03-17 08:48:30','2020-03-17 08:48:30'),(9,'GUIDELINES FOR THE CONDUCT OF CLASSES','announcement',NULL,'<p><img alt=\"\" src=\"/storage/img/updates/images/mar-17-2020%20guideline-classes.jpg\" /></p>',1,1,'2020-03-17 08:48:31','2020-03-17 08:48:31'),(10,'DIOCESAN CIRCULAR No. 8, Series of 2020','announcement',NULL,'<p><img alt=\"\" src=\"/storage/img/updates/images/diocesan-circular-no_8.jpg\" /></p>',1,1,'2020-03-22 08:48:30','2020-03-22 08:48:30'),(11,'OFFICIAL RESPONSE OF THE FATHER PRESIDENT','announcement','[INFORMATION] Official Response of the Father President pertaining to the continuation of online classes in DWC Legazpi, for reference and guidance.','<p>[INFORMATION] Official Response of the Father President pertaining to the continuation of online classes in DWC Legazpi, for reference and guidance.</p>\r\n\r\n<p><img alt=\"\" src=\"/storage/img/updates/images/apr-01-2020%20father-response.jpg\" /></p>',1,1,'2020-04-01 08:48:30','2020-04-01 08:48:30'),(12,'REVISED SCHOOL ACTIVITIES FOR THE 2ND SEMESTER','announcement','In light of recent government updates on CoViD-19, and having in mind the safety and well-being of the school ...','<p>In light of recent government updates on CoViD-19, and having in mind the safety and well-being of the school community, the administrators of Divine Word College of Legazpi ,headed by Rev. Fr. Nielo M. Cantilado, SVD, released this Memorandum pertaining to the Revised School Activities for the 2nd Semester, AY 2019-2020.</p>\r\n\r\n<p><img alt=\"\" src=\"/storage/img/updates/images/apr-14-2020%20revised-school-activities.jpg\" /></p>',1,1,'2020-04-14 08:48:30','2020-04-14 08:48:30'),(13,'GUIDELINES IN POSTING OFFICIAL COMMUNICATION','announcement',NULL,'<p><img alt=\"\" src=\"/storage/img/updates/images/apr-21-2020%20guidelines-posting-communication.jpg\" /></p>',1,1,'2020-05-14 08:48:30','2020-05-14 08:48:30'),(14,'ACKNOWLEDGE RECEIPT OF OPEN LETTER DATED MAY 4, 2020','announcement',NULL,'<p><img alt=\"\" src=\"/storage/img/updates/images/may-14-2020%20acknowledge-receipt-letter.jpg\" /><img alt=\"\" src=\"/storage/img/updates/images/may-14-2020%20acknowledge-receipt-letter-2.jpg\" /></p>',1,1,'2020-05-14 11:18:03','2020-05-14 11:18:03'),(15,'CHANGES/UPDATES TO MEMO NO.9, s. 2020','announcement',NULL,'<p><img alt=\"\" src=\"/storage/img/updates/images/may-14-2020%20changes-updates-memo.jpg\" /><img alt=\"\" src=\"/storage/img/updates/images/may-14-2020%20changes-updates-memo-2.jpg\" /><img alt=\"\" src=\"/storage/img/updates/images/may-14-2020%20changes-updates-memo-3.jpg\" /></p>',1,1,'2020-05-14 11:18:04','2020-05-14 11:18:04'),(16,'CANCELLATION OF TUITION FEE INCREASE, SY 2020-2021','announcement',NULL,'<p><img alt=\"\" src=\"/storage/img/updates/images/may-21-2020%20tuition-fee-cancellation.jpg\" /></p>',1,1,'2020-05-20 11:23:21','2020-05-20 11:23:21'),(17,'ENROLLMENT - BASIC EDUCATION','announcement',NULL,'<p><img alt=\"\" src=\"/storage/img/updates/images/may-27-2020%20enrollment-basic-ed.jpg\" /></p>',1,1,'2020-05-21 08:48:30','2020-05-21 08:48:30'),(18,'PLACEMENT TEST FOR GRADE 11 STUDENTS AND TRANSFEREES','announcement','Placement test will be administered during the first week of classes for Grade 11 students and transferees.','<p>Placement test will be administered during the first week of classes for Grade 11 students and transferees.</p>\r\n\r\n<p><img alt=\"\" src=\"/storage/img/updates/images/may-21-2020%20placement-test-grade-11-and-transferees-01.jpg\" /><img alt=\"\" src=\"/storage/img/updates/images/may-21-2020%20placement-test-grade-11-and-transferees-02.jpg\" /></p>',1,1,'2020-05-21 08:48:31','2020-05-21 08:48:31'),(19,'REITERATION OF GUIDELINES AND PROTOCOLS FOR STRICT COMPLIANCE DURING GCQ','announcement',NULL,'<p><img alt=\"\" src=\"/storage/img/updates/images/may-23-2020%20reiteration-guidelines-protocols.jpg\" /></p>',1,1,'2020-05-23 08:48:30','2020-05-23 08:48:30'),(20,'LEARNING DELIVERY MODALITIES','announcement','In case you’re wondering what blended learning is...','<p><img alt=\"\" src=\"/storage/img/updates/images/jun-06-2020%20learning-delivery-modalities.jpg\" /></p>',1,1,'2020-06-01 11:33:28','2020-06-01 11:33:28'),(21,'ENTRY PROTOCOLS AT DWCL CAMPUS DURING THE RELEASE OF STUDENTS\' CARDS','announcement','ATTN: BASIC ED PARENTS AND/OR GUARDIANS on June 15, 2020.','<p><img alt=\"\" src=\"/storage/img/updates/images/jun-10-2020%20entry-protocol-release-of-cards.jpg\" /></p>',1,1,'2020-06-10 11:34:49','2020-06-10 11:34:49');
/*!40000 ALTER TABLE `updates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin',1,'admin@gmail.com','2020-06-14 10:31:50','$2y$10$dZj9yqcQ0UKl2HRWJQOYnuArV./Xf3OA03ETz5qRM2.VNCHcJydv6','fvRDFbDmcD','2020-06-14 10:31:50','2020-06-14 10:31:50'),(2,'admin',1,'admin@gmail.com','2020-06-14 10:31:50','$2y$10$OECKBMmj/H8URNYmNjjKWOG2puwd0ahiFXIKmpoeT8I1x1LKN8I5i','DL7xNHzUGE','2020-06-14 10:31:50','2020-06-14 10:31:50'),(3,'admin',1,'admin@gmail.com','2020-06-14 10:31:50','$2y$10$Px.6W/.uhlnZeSXpIPWQa.NCEhk4qXE/TEyftvLYkW7XLUD3wqwN6','SjqT4gVdZ4','2020-06-14 10:31:50','2020-06-14 10:31:50'),(4,'sample',1,'sample@g.c','2020-06-14 10:31:51','$2y$10$yOhq02BQ9CY1PIzZwoVCee7MdFmzBmehBKBarm5zS3ti2e6grdygm',NULL,'2020-06-14 10:31:51','2020-06-14 10:31:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

